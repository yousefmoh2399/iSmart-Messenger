const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");

const storagePaths = require("../src/utils/storage-paths");

const originalUploadsDir = process.env.UPLOADS_DIR;
const originalUploadDir = process.env.UPLOAD_DIR;
const originalBackupsDir = process.env.BACKUPS_DIR;
const originalUpdateReleasesDir = process.env.UPDATE_RELEASES_DIR;
const originalReleasesDir = process.env.RELEASES_DIR;

test.afterEach(() => {
  if (originalUploadsDir === undefined) {
    delete process.env.UPLOADS_DIR;
  } else {
    process.env.UPLOADS_DIR = originalUploadsDir;
  }
  if (originalUploadDir === undefined) {
    delete process.env.UPLOAD_DIR;
  } else {
    process.env.UPLOAD_DIR = originalUploadDir;
  }
  if (originalBackupsDir === undefined) {
    delete process.env.BACKUPS_DIR;
  } else {
    process.env.BACKUPS_DIR = originalBackupsDir;
  }
  if (originalUpdateReleasesDir === undefined) {
    delete process.env.UPDATE_RELEASES_DIR;
  } else {
    process.env.UPDATE_RELEASES_DIR = originalUpdateReleasesDir;
  }
  if (originalReleasesDir === undefined) {
    delete process.env.RELEASES_DIR;
  } else {
    process.env.RELEASES_DIR = originalReleasesDir;
  }
});

test("getUploadsRoot supports defaults, relative paths, and absolute paths", () => {
  delete process.env.UPLOADS_DIR;
  delete process.env.UPLOAD_DIR;
  assert.equal(
    storagePaths.getUploadsRoot(),
    path.join(storagePaths.getBackendRoot(), "uploads"),
  );

  process.env.UPLOAD_DIR = "runtime/files";
  assert.equal(
    storagePaths.getUploadsRoot(),
    path.join(storagePaths.getBackendRoot(), "runtime/files"),
  );

  process.env.UPLOADS_DIR = path.join(os.tmpdir(), "configured-uploads");
  assert.equal(
    storagePaths.getUploadsRoot(),
    path.normalize(process.env.UPLOADS_DIR),
  );
});

test("configured backup and update release roots support env paths", () => {
  delete process.env.BACKUPS_DIR;
  delete process.env.UPDATE_RELEASES_DIR;
  delete process.env.RELEASES_DIR;

  assert.equal(
    storagePaths.getBackupsRoot(),
    path.join(storagePaths.getBackendRoot(), "backups"),
  );
  assert.equal(
    storagePaths.getUpdateReleasesRoot(),
    path.join(storagePaths.getBackendRoot(), "releases"),
  );

  process.env.BACKUPS_DIR = "../server-storage/backups";
  process.env.UPDATE_RELEASES_DIR = "../server-storage/releases";

  assert.equal(
    storagePaths.getBackupsRoot(),
    path.resolve(storagePaths.getBackendRoot(), "../server-storage/backups"),
  );
  assert.equal(
    storagePaths.getUpdateReleasesRoot(),
    path.resolve(storagePaths.getBackendRoot(), "../server-storage/releases"),
  );

  delete process.env.UPDATE_RELEASES_DIR;
  process.env.RELEASES_DIR = path.join(os.tmpdir(), "legacy-releases");
  assert.equal(
    storagePaths.getUpdateReleasesRoot(),
    path.normalize(process.env.RELEASES_DIR),
  );
});

test("sanitizePathSegment removes traversal and unsafe characters", () => {
  assert.equal(storagePaths.sanitizePathSegment(null, "fallback"), "fallback");
  assert.equal(
    storagePaths.sanitizePathSegment(" ../ reports / <daily>:2026?.pdf "),
    path.join("reports", "_daily__2026_.pdf"),
  );
  assert.equal(
    storagePaths.sanitizePathSegment("folder\\nested\\file.txt"),
    path.join("folder", "nested", "file.txt"),
  );
});

test("isPathInsideRoot rejects sibling and parent paths", () => {
  const root = path.join(os.tmpdir(), "uploads-root");

  assert.equal(storagePaths.isPathInsideRoot(root, root), true);
  assert.equal(
    storagePaths.isPathInsideRoot(root, path.join(root, "chat", "file.pdf")),
    true,
  );
  assert.equal(
    storagePaths.isPathInsideRoot(root, `${root}-other/file.pdf`),
    false,
  );
  assert.equal(
    storagePaths.isPathInsideRoot(root, path.dirname(root)),
    false,
  );
});

test("upload directory helpers stay inside the configured root", () => {
  process.env.UPLOADS_DIR = path.join(os.tmpdir(), "uploads-root");

  assert.equal(
    storagePaths.resolveUploadPath("..", "chat", "../room", "file.pdf"),
    path.join(process.env.UPLOADS_DIR, "chat", "room", "file.pdf"),
  );
  assert.equal(
    storagePaths.getChatUploadsDir("room-1"),
    path.join(process.env.UPLOADS_DIR, "chat", "room-1"),
  );
  assert.equal(
    storagePaths.getChatTransferUploadsDir("user-1"),
    path.join(process.env.UPLOADS_DIR, "chat_transfers", "user-1"),
  );
  assert.equal(
    storagePaths.getAvatarUploadsDir("user-1"),
    path.join(process.env.UPLOADS_DIR, "avatars", "user-1"),
  );
  assert.equal(
    storagePaths.getDocumentsUploadsDir("user-1"),
    path.join(process.env.UPLOADS_DIR, "user-1"),
  );
});

test("ensureDirectory and fileExists reflect filesystem state", async (t) => {
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "storage-paths-"));
  t.after(() => fs.rm(tempRoot, { recursive: true, force: true }));
  const directory = path.join(tempRoot, "nested");
  const filePath = path.join(directory, "file.txt");

  assert.equal(await storagePaths.fileExists(null), false);
  assert.equal(await storagePaths.fileExists(filePath), false);
  assert.equal(await storagePaths.ensureDirectory(directory), directory);
  await fs.writeFile(filePath, "content");
  assert.equal(await storagePaths.fileExists(filePath), true);
});

test("relative and stored upload paths are normalized safely", () => {
  process.env.UPLOADS_DIR = path.join(os.tmpdir(), "uploads-root");
  const filePath = path.join(process.env.UPLOADS_DIR, "chat", "file.pdf");

  assert.equal(
    storagePaths.toRelativeUploadPath(filePath),
    path.join("chat", "file.pdf"),
  );
  assert.equal(storagePaths.toRelativeUploadPath(null), null);
  assert.throws(
    () => storagePaths.toRelativeUploadPath(path.join(os.tmpdir(), "elsewhere")),
    /outside uploads root/,
  );

  assert.equal(storagePaths.resolveStoredUploadPath(null), null);
  assert.equal(
    storagePaths.resolveStoredUploadPath("chat/file.pdf"),
    filePath,
  );
  assert.equal(
    storagePaths.resolveStoredUploadPath("uploads-root/chat/file.pdf"),
    filePath,
  );
  assert.equal(storagePaths.resolveStoredUploadPath(filePath), filePath);
  assert.equal(
    storagePaths.resolveStoredUploadPath(
      path.join(os.tmpdir(), "legacy", "uploads-root", "chat", "file.pdf"),
    ),
    filePath,
  );
  assert.equal(
    storagePaths.resolveStoredUploadPath(
      path.join(os.tmpdir(), "legacy", "unknown", "file.pdf"),
    ),
    null,
  );
});

test("stored update release paths can move from legacy releases root", () => {
  process.env.UPDATE_RELEASES_DIR = path.join(os.tmpdir(), "new-releases");

  assert.equal(storagePaths.resolveStoredUpdateReleasePath(null), null);
  assert.equal(
    storagePaths.resolveStoredUpdateReleasePath("installer.zip"),
    path.join(process.env.UPDATE_RELEASES_DIR, "installer.zip"),
  );
  assert.equal(
    storagePaths.resolveStoredUpdateReleasePath(
      path.join(os.tmpdir(), "legacy", "releases", "installer.zip"),
    ),
    path.join(process.env.UPDATE_RELEASES_DIR, "installer.zip"),
  );
});
